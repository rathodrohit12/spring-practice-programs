package com.bh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proj6RestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
