package com.bh.service;

import com.bh.model.EmpModel;

public interface EmpService {

	EmpModel empRegisterService(EmpModel empModel);
 
	//EmpModel getUserByEmailOrMobile(EmpModel empModel);

	//EmpModel getUserByEmailOrMobile(EmpModel empModel);
}
