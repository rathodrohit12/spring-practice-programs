package com.bh.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.bh.entity.EmpEntity;
import com.bh.model.EmpModel;
import com.bh.repository.EmpRepository;
import com.bh.utils.OTPGenerator;

@Service
public class EmpServiceImpl implements EmpService {

	EmpRepository empRepository;
	ModelMapper modelMapper;

	public EmpServiceImpl(EmpRepository empRepository, ModelMapper modelMapper) {
		super();
		this.empRepository = empRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public EmpModel empRegisterService(EmpModel empModel) {

		Optional<EmpEntity> byEmailOrMobile = empRepository.findByEmailOrMobile(empModel.getEmail(),
				empModel.getMobile());
		if (byEmailOrMobile.isPresent()) {
			return null;
		}
		empModel.setStatus("inactive");
		empRepository.save(modelMapper.map(empModel, EmpEntity.class));

		String otp = OTPGenerator.generateOTP();
		// SendEmail.sendOtp(empModel.getEmail(), otp);
		return empModel;

	}

//
//	@Override
//	public EmpModel getUserByEmailOrMobile(EmpModel empModel) {
//		
//		return modelMapper.map(empRepository.findByEmailOrMobile(empModel.getEmail(),empModel.getMobile()),EmpModel.class);
//	}

}
