package com.bh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proj6RestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proj6RestApiApplication.class, args);
	}

}
