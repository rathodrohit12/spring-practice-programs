package com.bh.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bh.model.EmpModel;
import com.bh.service.EmpService;

import com.bh.utils.ResponseHandler;


import jakarta.validation.Valid;

@RestController
@RequestMapping("/emp")
public class EmpController {

	EmpService empService;

	public EmpController(EmpService empService) {
		super();
		this.empService = empService;
	}

	@PostMapping("/register")
	public ResponseEntity<Object> empRegister(@Valid @RequestBody EmpModel empModel) {
		EmpModel empModel2 = empService.empRegisterService(empModel);

		if (empModel2 == null) {

			return ResponseHandler.generateResponse(HttpStatus.BAD_REQUEST, false, "employee already exist", empModel);

		}

		else {
			return ResponseHandler.generateResponse(HttpStatus.CREATED, true, "Customer Register Successfuly",
					empModel2);

		}
	}
}
